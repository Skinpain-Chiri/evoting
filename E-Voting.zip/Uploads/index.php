<html>
<head>
<title>Upload the files</title>
</head>
<body>
<form action='process.php' method='POST' enctype='multipart/form-data'>
<label>
Upload the file:
<input type='file' name='video'>
<br><br>
<button type='submit' name='submit'>Upload</button>
</form>
