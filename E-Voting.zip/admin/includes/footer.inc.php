<?php
	echo "<footer class='center-block' style='margin-top: 30px;'><hr>"; 
	echo "<p align='center'>Copyright &copy; 2018. Programmed by: <b><u>Ashraf Abdul-Muumin</u></b> & <b><u>Moro Tijani</u></b></p>";
	echo "</footer>";
?>