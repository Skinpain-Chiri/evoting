<?php
	$servername = 'localhost';
	$username = 'root';
	$password = 'ashraf';
	$db_name = 'evoting';

	$conn = mysqli_connect($servername, $username, $password, $db_name);

?>