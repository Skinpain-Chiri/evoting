<div align='center'>
					<form action='includes/signout.inc.php' method='POST'>
					<button type='submit' class='btn btn-warning' name='really'>Signout</button>
					</form>
</div>